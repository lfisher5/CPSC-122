#include <iostream>
#include <cstring>
#include <cctype>
using namespace std;

#include "calc.h"

Calc::Calc(int argcIn, char* argv[])
{

	
	inFix = new char[strlen(argv[1])+1]; 
	postFix = new char[strlen(argv[1])+1]; 
	hashTble = new int[26];
	
	
	strcpy(inFix, argv[1]);

	
	int j = 2;
	for(int i = 0; i < strlen(argv[1]); i++)
	{
		
		if(isupper(inFix[i]))
			{
				int num = inFix[i] - 65;
				hashTble[num] = atoi(argv[j]);
				j++;
			}
	}
	
	
	
	if(!CheckTokens())
	{
		cout << "Illegal tokens"<< endl;
		exit(-1);
	}
	if(!CheckParens())
	{
		cout << "Parentheses not balanced" << endl;
		exit(-1);
	}




}




Calc::~Calc()
{


delete stk;
delete inFix;
delete postFix;
delete hashTble;



}

bool Calc::CheckTokens()//Good
{
	for(int i = 0; i < strlen(inFix); i++)
	{
		if(!isupper(inFix[i])&&!IsOp(inFix[i]))
			return false;
	}		
	return true;
}

bool Calc:: IsOp(char ch)
{
	if(ch == '(')
		return true;
	if(ch == ')')
		return true;
	if(ch == '+')
		return true;
	if(ch == '-')
		return true;	
	if(ch == '*')
		return true;
	if(ch == '/')
		return true;	
	
	return false;	

}

bool Calc::CheckParens()
{
int i = 0;

	stk = new Stack;
	
	for(int i = 0; i < strlen(inFix); i++)
	{
		if(inFix[i] == '(')
			stk->Push(inFix[i]);
			else
				if(inFix[i] == ')')
					if(stk->IsEmpty())
						return false;
			else
				stk->Pop();			
			
		
	}		
	
	if(stk->IsEmpty())
		return true;
	else 
		return false;
				
		delete stk;		
}
	






